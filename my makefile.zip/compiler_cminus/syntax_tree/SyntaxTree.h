#ifndef __SYNTAXTREE_H__
#define __SYNTAXTREE_H__

#include <stdio.h>

//#include "lab1_lexical_analyzer/lexical_analyzer.h"

//extern int yylineno;
//extern char* yytext;
void yyerror(char *s,...);






struct _SyntaxTreeNode {
	int line;
	struct _SyntaxTreeNode * l;
	struct _SyntaxTreeNode * r;
        struct _SyntaxTreeNode * parent;
	struct _SyntaxTreeNode * children[1000];
	int children_num;
	char *name;
	union
    {
    	char* idtype;
    	int intgr;
    };
};
typedef struct _SyntaxTreeNode SyntaxTreeNode;

SyntaxTreeNode *newast(char* name,int num,...);
void eval(SyntaxTreeNode *a,int level);

SyntaxTreeNode * newSyntaxTreeNodeNoName();
SyntaxTreeNode * newSyntaxTreeNode(const char * name);
struct _SyntaxTreeNode * init_node(char * name,int num,...);
int SyntaxTreeNode_AddChild(SyntaxTreeNode * parent, SyntaxTreeNode * child);
void deleteSyntaxTreeNodeNoRecur(SyntaxTreeNode * node);
void deleteSyntaxTreeNode(SyntaxTreeNode * node, int recursive);

struct _SyntaxTree {
	SyntaxTreeNode * root;
};
typedef struct _SyntaxTree SyntaxTree;

SyntaxTree * newSyntaxTree();
void deleteSyntaxTree(SyntaxTree * tree);
void printSyntaxTree(FILE * fout, SyntaxTree * tree);
void printSyntaxTreeNode(FILE * fout, SyntaxTreeNode * node, int level);

#endif /* SyntaxTree.h */
