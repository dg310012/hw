#include <stdlib.h>
#include <string.h>
#include<stdio.h> 
# include<stdarg.h>
#include "SyntaxTree.h"
//#include "lab1_lexical_analyzer/lexical_analyzer.h"
//#include "lexical_analyzer.h"
  
//extern int yywrap(void);  
//extern int yylex(void);





struct _SyntaxTreeNode * init_node(char * name,int num,...)
{
	va_list valist;
	SyntaxTreeNode * tmp;
	tmp=newSyntaxTreeNode(name);
	va_start(valist,num);
	int i;
	for(i=0;i<num;i++)
	{
		tmp->children[i]=va_arg(valist, SyntaxTreeNode *);
		tmp->children[i]->parent=tmp;
	}
	va_end(valist);
	tmp->children_num=num;
	return tmp;
}

SyntaxTreeNode *newast(char* name,int num,...)
{
	int i;
	va_list valist;
    SyntaxTreeNode* a=(SyntaxTreeNode* )malloc(sizeof(SyntaxTreeNode));
    SyntaxTreeNode* temp=(SyntaxTreeNode* )malloc(sizeof(SyntaxTreeNode));
    if(!a) 
    {
//        yyerror("out of space");
        exit(0);
    }
    a->name=name;
    va_start(valist,num);
    a->children_num=num;

    if(num>0)
    {
        temp=va_arg(valist, SyntaxTreeNode*);
        a->l=temp;
	a->children[0]=temp;
        a->line=temp->line;

        if(num>=2) 
        {
            for(i=0; i<num-1; ++i)
            {
                temp->r=va_arg(valist,SyntaxTreeNode*);
                temp=temp->r;
		a->children[i+1]=temp;
            }
        }
    }
    else 
    {
        int t=va_arg(valist,int); 
        a->line=t;
/*        if((!strcmp(a->name,"IDENTIFIER"))||(!strcmp(a->name,"INT"))||(!strcmp(a->name,"VOID"))){
        	char* t;
			t=(char*)malloc(sizeof(char*)*40);
			strcpy(t,yytext);
			a->idtype=t;
		}
        else if(!strcmp(a->name,"NUMBER")) 
			{a->intgr=atoi(yytext);}
        else 
			{}*/
    }
    return a;
}


void eval(SyntaxTreeNode *a,int level)
{
	int i;
    if(a!=NULL)
    {
        for(i=0; i<level; ++i)
            printf("  ");
        if(a->line!=-1){ 
            printf("%s ",a->name);
            if((!strcmp(a->name,"IDENTIFIER"))||(!strcmp(a->name,"INT"))||(!strcmp(a->name,"VOID")))
				printf(":%s ",a->idtype);
            else if(!strcmp(a->name,"INTEGER"))printf(":%d",a->intgr);
            else
                printf("(%d)",a->line);
        }
        printf("\n");

        eval(a->l,level+1);
        eval(a->r,level);
    }
}

void printSyntaxTreeNode(FILE * fout, SyntaxTreeNode * node, int level)
{
	// assume fout valid now
	
	// print myself
	int i;
	for (i = 0; i < level; i++) {
		fprintf(fout, "|  ");
	}
	fprintf(fout, ">--%s %s\n", (node->children_num ? "+" : "*"), node->name);

	for (i = 0; i < node->children_num; i++) {
		printSyntaxTreeNode(fout, node->children[i], level + 1);
	}
}

SyntaxTreeNode * newSyntaxTreeNodeNoName()
{
	return newSyntaxTreeNode(NULL);
}

SyntaxTreeNode * newSyntaxTreeNode(const char * name)
{
	SyntaxTreeNode * newNode = (SyntaxTreeNode *)malloc(sizeof(SyntaxTreeNode));
	if (name)
		strcpy(newNode->name, name);
	return newNode;
}

int SyntaxTreeNode_AddChild(SyntaxTreeNode * parent, SyntaxTreeNode * child)
{
	if (!parent || !child)	return -1;
	parent->children[parent->children_num++] = child;
	return parent->children_num;
}

void deleteSyntaxTreeNodeNoRecur(SyntaxTreeNode * node)
{
	deleteSyntaxTreeNode(node, 0);
}

void deleteSyntaxTreeNode(SyntaxTreeNode * node, int recursive)
{
	if (!node)	return;

	int i;
	if (recursive) {
		for (i = 0; i < node->children_num; i++) {
			deleteSyntaxTreeNode(node->children[i], 1);
		}
	}
	free(node);
}

SyntaxTree * newSyntaxTree()
{
	return (SyntaxTree *)malloc(sizeof(SyntaxTree));
}

void deleteSyntaxTree(SyntaxTree * tree)
{
	if (!tree)	return;

	if (tree->root) {
		deleteSyntaxTreeNode(tree->root, 1);
	}
	free(tree);
}



void printSyntaxTree(FILE * fout, SyntaxTree * tree)
{
	if (!fout)	return;
	
	printSyntaxTreeNode(fout, tree->root, 0);
}



/*void yyerror(char*s,...) //±ä³€²ÎÊýŽíÎóŽŠÀíº¯Êý
{
    va_list ap;
    va_start(ap,s);
    fprintf(stderr,"%d:error:",yylineno);//ŽíÎóÐÐºÅ
    vfprintf(stderr,s,ap);
    fprintf(stderr,"\n");
}
int main()
{
    printf(">");
    return yyparse(); //Æô¶¯ÎÄ·š·ÖÎö£¬µ÷ÓÃŽÊ·š·ÖÎö
}*/
