#include "common.h"
#include <dirent.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

int getAllTestcase(char filename[][256]){
    DIR *dirp; 
	int i=0;
    struct dirent *dp;
    char *name=".cminus";
    dirp = opendir("./testcase"); 
    while ((dp = readdir(dirp)) != NULL) { 
        if(!strcmp(dp->d_name+strlen(dp->d_name)-7,name))
        {
            strcpy(filename[i],dp->d_name);
			i+=1;
        }
    } 
    (void) closedir(dirp);
    return i;
}
